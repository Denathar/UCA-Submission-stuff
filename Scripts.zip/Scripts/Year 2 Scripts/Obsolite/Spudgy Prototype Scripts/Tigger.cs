﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tigger : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Ahh");
    }
}
