﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EventTypes { OnDestroyEvent, OnJumpEvent, OnFowardEvent }

public enum TargetTag { Nothing, Player, Enemy, Parent, Child, Box, HeavyBox, TriggerCollider, SpecialBox, LevelMesh,}

public class EnumStorage : MonoBehaviour
{

}
