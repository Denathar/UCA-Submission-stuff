﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInventory : MonoBehaviour
{
    public List<string> InventoryList;
    HUD hud;
   

    // Use this for initialization
    void Start ()
    {
        InventoryList = new List<string>();

       
    }
	
	// Update is called once per frame
	void Update ()
    {
      
    }
}
